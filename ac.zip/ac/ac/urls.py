"""
URL configuration for ac project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),
    path('dash/', views.dashboard),
    path('service-stats/', views.service_stats_api, name='service_stats_api'),
    path('service/', views.service),
    path('siteservice/', views.siteservice),
    path('choose/', views.choose),

    path('login/', views.login_),
    path('login_view/', views.login_view, name='login_view'),
    path('logout/', views.logout_view, name='logout'),

    path("appoint/", views.appoint, name="appoint"),
    path("booking-success/<int:booking_id>/", views.mark_booking_success, name="mark_booking_success"),
    path("booking-delete/<int:booking_id>/", views.delete_booking, name="delete_booking"),
    path("add-service-booking/",views.add_service_booking,name="add_service_booking"),



    path("contactlist/", views.contactlist, name="contactlist"),
    path("contact-success/<int:contact_id>/", views.mark_contact_success, name="mark_contact_success"),
    path("contact-delete/<int:contact_id>/", views.delete_contact, name="delete_contact"),
    path("contact-submit/", views.contact_submit, name="contact_submit"),


    path("servicelist/", views.servicelist, name="servicelist"),
    path("service_detail/<int:service_id>/", views.service_detail, name="service_detail"),
    path("add-service-query/", views.add_service_query, name="add_service_query"),
    path("query-success/<int:query_id>/", views.mark_query_success, name="mark_query_success"),
    path("query-delete/<int:query_id>/", views.delete_query, name="delete_query"),



    path('service/<int:id>/', views.servicedetail, name='service_detail'),
    path('about/', views.about),
    path('faq/', views.faq),
    path('contact/', views.contact),
    path('add-service/', views.add_service, name='add_service'),
    path("edit-service/<int:service_id>/", views.edit_service, name="edit_service"),
    path("get-service/<int:service_id>/", views.get_service, name="get_service"),
    path('delete-service/<int:service_id>/', views.delete_service, name='delete_service'),



]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
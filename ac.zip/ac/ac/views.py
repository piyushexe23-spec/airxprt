from django.contrib.auth import authenticate, login,get_user_model
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, JsonResponse, Http404
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Count
from django.contrib.auth import logout
from django.contrib.auth.models import User
from manegr.models import Service,ServiceBooking,ContactQuery,ServiceQuery


def login_(request):
    return render(request,"login.html")

def logout_view(request):
    logout(request)
    return redirect('/login/')

@csrf_exempt
def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")
        errors = {}

        try:
            user_obj = User.objects.get(email=email)
        except User.DoesNotExist:
            errors["email"] = "User with this email does not exist."
            return JsonResponse({"success": False, "errors": errors})

        user = authenticate(request, username=user_obj.username, password=password)

        if user is not None:
            login(request, user)
            return JsonResponse({"success": True, "redirect_url": "/dash/"})
        else:
            errors["password"] = "Invalid email or password."
            return JsonResponse({"success": False, "errors": errors})

        return JsonResponse({"success": False, "errors": {"general": "Invalid request method."}})

def index(request):
    services = Service.objects.filter(is_active=True)
    featured_services = Service.objects.filter(is_featured=True,is_active=True).order_by('-id')[:3]
    return render(request, "index.html",{'services':services,'featured_services': featured_services,})

@login_required(login_url='/login/')
def dashboard(request):
    total_services = Service.objects.filter(is_active=True).count()

    featured_services = Service.objects.filter(
        is_featured=True,
        is_active=True
    )

    total_featured_services = Service.objects.filter(
        is_featured=True,
        is_active=True
    ).count()

    top_services = (
        Service.objects
        .annotate(query_count=Count('servicequery'))
        .filter(query_count__gt=0)
        .order_by('-query_count')[:2]
    )

    return render(
        request,
        "dash.html",
        {
            'name': 'Dashboard',
            'featured_services': featured_services,
            'total_services': total_services,
            'total_featured_services': total_featured_services,
            'top_services': top_services,
        }
    )
@login_required(login_url='/login/')
def service(request):
    service = Service.objects.all()
    total_services = Service.objects.filter(is_active=True).count()
    total_featured_services = Service.objects.filter(
        is_featured=True,
        is_active=True
    ).count()

    top_services = (
        Service.objects
        .annotate(query_count=Count('servicequery'))
        .filter(query_count__gt=0)
        .order_by('-query_count')[:2]
    )

    return render(
        request,
        "service.html",
        {
            'service': service,
            'name': 'Services',
            'total_services': total_services,
            'total_featured_services': total_featured_services,
            'top_services': top_services,
        }
    )
def choose(request):
    return render(request, "choose.html")

def about(request):
    return render(request, "about.html")

def faq(request):
    return render(request, "faq.html")


@login_required(login_url='/login/')
def appoint(request):
    all_bookings = ServiceBooking.objects.all().order_by("-created_at")
    pending_bookings = ServiceBooking.objects.filter(status="pending").order_by("-created_at")
    success_bookings = ServiceBooking.objects.filter(status="success").order_by("-created_at")

    return render(request, "appointment.html", {
        'name':'Online Appointment',
        "all_bookings": all_bookings,
        "pending_bookings": pending_bookings,
        "success_bookings": success_bookings,
    })


def mark_booking_success(request, booking_id):
    booking = get_object_or_404(ServiceBooking, id=booking_id)
    booking.status = "success"
    booking.save()

    # redirect so page updates correctly
    return redirect("appoint")


def delete_booking(request, booking_id):
    booking = get_object_or_404(ServiceBooking, id=booking_id)
    booking.delete()

    return redirect("appoint")


def contact(request):
    return render(request, "contact.html")

def siteservice(request):
    service = Service.objects.all()
    return render(request, "siteservice.html",{'service':service,})

def servicedetail(request, id):
    service = get_object_or_404(Service, id=id)
    servicelist = Service.objects.all()
    return render(request, "servicedetail.html", {'service': service,'servicelist': servicelist,})

@login_required(login_url='/login/')
def contactlist(request):
    all_contacts = ContactQuery.objects.all().order_by("-created_at")
    pending_contacts = ContactQuery.objects.filter(status="pending").order_by("-created_at")
    success_contacts = ContactQuery.objects.filter(status="success").order_by("-created_at")

    return render(request, "contactdash.html", {
        'name':'Contact Query',
        "all_contacts": all_contacts,
        "pending_contacts": pending_contacts,
        "success_contacts": success_contacts,
    })

def mark_contact_success(request, contact_id):
    contact = get_object_or_404(ContactQuery, id=contact_id)
    contact.status = "success"
    contact.save()
    return redirect("contactlist")

def delete_contact(request, contact_id):
    contact = get_object_or_404(ContactQuery, id=contact_id)
    contact.delete()
    return redirect("contactlist")


def delete_contact(request, contact_id):
    contact = get_object_or_404(ContactQuery, id=contact_id)
    contact.delete()
    return redirect("contactlist")

@login_required(login_url='/login/')
def servicelist(request):
    service = Service.objects.all()
    total_services = Service.objects.filter(is_active=True).count()
    total_featured_services = Service.objects.filter(is_featured=True, is_active=True).count()
    top_services = (Service.objects.annotate(query_count=Count('servicequery')).filter(query_count__gt=0).order_by('-query_count')[:2])
    return render(request, "servicelist.html",{'service':service,'name':'Service List','total_services':total_services,'top_services':top_services,'total_featured_services':total_featured_services})


@login_required(login_url='/login/')
def service_detail(request, service_id):
    service = get_object_or_404(Service, id=service_id)

    all_queries = ServiceQuery.objects.filter(service=service).order_by("-created_at")
    pending_queries = all_queries.filter(status="pending")
    success_queries = all_queries.filter(status="success")

    return render(request, "service_detail.html", {
        'name':'Service Details',
        "service": service,
        "all_queries": all_queries,
        "pending_queries": pending_queries,
        "success_queries": success_queries,
    })

def mark_query_success(request, query_id):
    query = get_object_or_404(ServiceQuery, id=query_id)
    query.status = "success"
    query.save()
    return redirect("service_detail", service_id=query.service.id)

def delete_query(request, query_id):
    query = get_object_or_404(ServiceQuery, id=query_id)
    service_id = query.service.id
    query.delete()
    return redirect("service_detail", service_id=service_id)




def add_service(request):
    if request.method == "POST":
        try:
            service_image = request.FILES.get("service_image")
            banner_image = request.FILES.get("banner_image")
            service_name = request.POST.get("service_name")
            about_service = request.POST.get("about_service")
            service_price = request.POST.get("service_price")
            service_overview = request.POST.get("service_overview")
            one_line_point = request.POST.get("one_line_point")
            point1 = request.POST.get("point1", "")
            point2 = request.POST.get("point2", "")
            point3 = request.POST.get("point3", "")

            # 🔥 FEATURED TOGGLE
            is_featured = True if request.POST.get("is_featured") == "on" else False

            # Validate required fields
            if not all([
                service_name,
                banner_image,
                about_service,
                service_price,
                service_overview,
                one_line_point,
            ]):
                return JsonResponse(
                    {"status": "error", "message": "All required fields must be filled"},
                    status=400
                )

            service = Service.objects.create(
                service_image=service_image,
                banner_image=banner_image,
                service_name=service_name,
                about_service=about_service,
                service_price=service_price,
                service_overview=service_overview,
                one_line_point=one_line_point,
                point1=point1,
                point2=point2,
                point3=point3,
                is_featured=is_featured  # ✅ SAVED HERE
            )

            return JsonResponse({
                "status": "success",
                "id": service.id,
                "message": "Service added successfully"
            })

        except Exception as e:
            return JsonResponse(
                {"status": "error", "message": str(e)},
                status=500
            )

    return JsonResponse(
        {"status": "error", "message": "Invalid request"},
        status=400
    )



def edit_service(request, service_id):
    if request.method == "POST":
        service = get_object_or_404(Service, id=service_id)

        service.service_name = request.POST.get("service_name")
        service.about_service = request.POST.get("about_service")
        service.service_price = request.POST.get("service_price")
        service.service_overview = request.POST.get("service_overview")
        service.one_line_point = request.POST.get("one_line_point")
        service.point1 = request.POST.get("point1", "")
        service.point2 = request.POST.get("point2", "")
        service.point3 = request.POST.get("point3", "")

        # 🔥 FEATURED TOGGLE
        service.is_featured = True if request.POST.get("is_featured") == "on" else False

        if request.FILES.get("service_image"):
            service.service_image = request.FILES.get("service_image")

        if request.FILES.get("banner_image"):
            service.banner_image = request.FILES.get("banner_image")

        service.save()

        return JsonResponse({
            "status": "success",
            "message": "Service updated successfully"
        })

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def get_service(request, service_id):
    service = get_object_or_404(Service, id=service_id)

    return JsonResponse({
        "status": "success",
        "service": {
            "service_name": service.service_name,
            "about_service": service.about_service,
            "service_price": service.service_price,
            "service_overview": service.service_overview,
            "one_line_point": service.one_line_point,
            "point1": service.point1,
            "point2": service.point2,
            "point3": service.point3,
            "is_featured": service.is_featured  # ✅ added
        }
    })


def delete_service(request, service_id):
    service = get_object_or_404(Service, id=service_id)
    service.delete()
    return redirect('/service/')


def add_service_booking(request):
    if request.method == "POST":
        try:
            full_name = request.POST.get("full_name")
            phone_number = request.POST.get("phone_number")
            service_id = request.POST.get("service_id")

            # Validation
            if not all([full_name, phone_number, service_id]):
                return JsonResponse(
                    {"status": "error", "message": "All fields are required"},
                    status=400
                )

            service = Service.objects.get(id=service_id)

            booking = ServiceBooking.objects.create(
                full_name=full_name,
                phone_number=phone_number,
                service=service
            )

            return JsonResponse({
                "status": "success",
                "id": booking.id,
                "message": "Booking submitted successfully"
            })

        except Service.DoesNotExist:
            return JsonResponse(
                {"status": "error", "message": "Invalid service selected"},
                status=400
            )

        except Exception as e:
            return JsonResponse(
                {"status": "error", "message": str(e)},
                status=500
            )

    return JsonResponse(
        {"status": "error", "message": "Invalid request"},
        status=400
    )


def contact_submit(request):
    if request.method == "POST":
        try:
            name = request.POST.get("name")
            phone = request.POST.get("phone")
            message = request.POST.get("message")

            if not all([name, phone, message]):
                return JsonResponse(
                    {"status": "error", "message": "All fields are required"},
                    status=400
                )

            ContactQuery.objects.create(
                name=name,
                phone=phone,
                message=message
            )

            return JsonResponse({
                "status": "success",
                "message": "Message sent successfully"
            })

        except Exception as e:
            return JsonResponse(
                {"status": "error", "message": str(e)},
                status=500
            )

    return JsonResponse(
        {"status": "error", "message": "Invalid request"},
        status=400
    )


def add_service_query(request):
    if request.method == "POST":
        try:
            name = request.POST.get("name")
            phone = request.POST.get("phone")
            address = request.POST.get("address")
            pincode = request.POST.get("pincode")
            message = request.POST.get("message")
            service_id = request.POST.get("service_id")

            # Validation
            if not all([name, phone, pincode, message, service_id]):
                return JsonResponse(
                    {
                        "status": "error",
                        "message": "Name, phone, pincode, service and message are required"
                    },
                    status=400
                )

            service = get_object_or_404(Service, id=service_id)

            query = ServiceQuery.objects.create(
                service=service,
                name=name,
                phone=phone,
                address=address,
                pincode=pincode,
                message=message
            )

            return JsonResponse({
                "status": "success",
                "id": query.id,
                "message": "Query submitted successfully"
            })

        except Exception as e:
            return JsonResponse(
                {"status": "error", "message": str(e)},
                status=500
            )

    return JsonResponse(
        {"status": "error", "message": "Invalid request"},
        status=400
    )



def service_stats_api(request):
    data = (
        ServiceQuery.objects
        .values('service__service_name')
        .annotate(total=Count('id'))
        .order_by('-total')
    )

    services = []
    totals = []

    for item in data:
        services.append(item['service__service_name'])
        totals.append(item['total'])

    return JsonResponse({
        'services': services,
        'totals': totals
    })
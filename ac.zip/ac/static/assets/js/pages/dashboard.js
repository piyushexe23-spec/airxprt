// let category_options = {
//     series: [44, 55, 41, 17],
//     labels: ['Cloths', 'Devices', 'Bags', 'Watches'],
//     chart: {
//         type: 'donut',
//     },
//     colors: ['#6ab04c', '#2980b9', '#f39c12', '#d35400']
// }

// let category_chart = new ApexCharts(document.querySelector("#category-chart"), category_options)
// category_chart.render()


fetch('/service-stats/')
    .then(response => response.json())
    .then(data => {

        let customer_options = {
            series: [{
                name: "Service Queries",
                data: data.totals
            }],
            chart: {
                height: 320,
                type: 'bar',
                toolbar: {
                    show: true
                }
            },
            colors: ['#3C21F7'],
            plotOptions: {
                bar: {
                    borderRadius: 6,
                    columnWidth: '45%'
                }
            },
            dataLabels: {
                enabled: true
            },
            xaxis: {
                categories: data.services,
                labels: {
                    rotate: -35,
                    style: {
                        fontSize: '12px'
                    }
                }
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Queries";
                    }
                }
            }
        };

        let customer_chart = new ApexCharts(
            document.querySelector("#customer-chart"),
            customer_options
        );

        customer_chart.render();
    });

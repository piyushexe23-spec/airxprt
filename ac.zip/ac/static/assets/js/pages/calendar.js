//______calendar
$('.custom-calendar').pignoseCalendar({
    disabledDates: [
        '2021-01-20'
    ],
    format: 'YYY-MM-DD'
});
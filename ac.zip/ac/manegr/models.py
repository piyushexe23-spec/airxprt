from django.db import models

# Create your models here.
class Service(models.Model):

    service_image = models.ImageField(upload_to='services/', null=True, blank=True)
    banner_image = models.ImageField(upload_to='services/', null=True, blank=True)

    service_name = models.CharField(max_length=255)
    about_service = models.TextField()
    service_price = models.DecimalField(max_digits=10, decimal_places=2)
    service_overview = models.TextField()
    one_line_point = models.CharField(max_length=999)
    is_featured = models.BooleanField(default=False)

    point1 = models.CharField(max_length=999, blank=True, default="")
    point2 = models.CharField(max_length=999, blank=True, default="")
    point3 = models.CharField(max_length=999, blank=True, default="")

    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.service_name


class ServiceBooking(models.Model):
    STATUS_CHOICES = (
        ("pending", "Pending"),
        ("success", "Success"),
    )

    full_name = models.CharField(max_length=255)
    phone_number = models.CharField(max_length=20)
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.full_name} - {self.service.service_name}"

class ContactQuery(models.Model):
    STATUS_CHOICES = (
        ("pending", "Pending"),
        ("success", "Success"),
    )

    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    message = models.TextField()
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="pending"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class ServiceQuery(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    address = models.TextField(blank=True)
    pincode = models.CharField(max_length=20, default="000000")
    message = models.TextField()
    status = models.CharField(
        max_length=20,
        choices=[("pending", "Pending"), ("success", "Success")],
        default="pending"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.service.service_name}"



from django.contrib import admin

# Register your models here.
from .models import Service
admin.site.register(Service)

from .models import ServiceBooking
admin.site.register(ServiceBooking)

from .models import ContactQuery
admin.site.register(ContactQuery)

from .models import ServiceQuery
admin.site.register(ServiceQuery)